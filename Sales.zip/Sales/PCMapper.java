package PaymentByCountry;

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.*;

public class PCMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

 public static int parseWithDefault(String number, int defaultVal) {
     try {
       return Integer.parseInt(number);
     } catch (NumberFormatException e) {
       return defaultVal;
     }
  }

 public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

    String line = value.toString();
    String[] data = line.split(",");
    String token = data[7];
    
    if (!token.startsWith("Country")) {
        context.write(new Text(data[7] + "\t" + data[3]), new IntWritable(1));
    }
  }
}

package PaymentByCountry;

import java.util.*;
import java.io.IOException;

import org.apache.hadoop.fs.*;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;

//import org.apache.hadoop.fs.Path;
//import org.apache.hadoop.mapreduce.Job;
//import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.Reducer;
//import org.apache.hadoop.util.*;

public class Driver {
  public static void main(String[] args) 
    throws IOException, InterruptedException, ClassNotFoundException {

    Configuration conf = new Configuration();

    // Set input and output directories using command line arguments,
    // arg[0] = name of the user
   
    Path input = new Path("/user/" + args[0] + "/sales/input");
    Path output = new Path("/user/" + args[0] + "/sales/output");

    // If OUTPUT already exists, detete it
    FileSystem fs = FileSystem.get(conf);
    if (fs.exists(output)) {
       fs.delete(output, true);
    }

    // Create an object for the job
    Job job = Job.getInstance(conf, "PaymentByCountry");
    
    job.setJarByClass(Driver.class);
    job.setMapperClass(PaymentByCountry.PCMapper.class);
    job.setReducerClass(PaymentByCountry.PCReducer.class);

    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);

    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(IntWritable.class);
    
    FileInputFormat.addInputPath(job, input);
    FileOutputFormat.setOutputPath(job, output);

    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}
